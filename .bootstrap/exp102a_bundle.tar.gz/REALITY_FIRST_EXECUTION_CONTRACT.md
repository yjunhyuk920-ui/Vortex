# VORTEX reality-first execution contract

This contract has the same authority as `AGENTS.md`,
`MISSION_AND_WORKING_PRINCIPLES.md`, the proof-first contract, and the
repository handoff mandate.

## 1. Promotion evidence must describe an executable world

A mechanism may advance the active runtime frontier only when every component
that must exist online is either:

1. implemented and measured in the declared environment;
2. represented by a sound measured upper bound from that environment; or
3. recorded as an unresolved positive cost that **blocks promotion**.

Unknown positive costs are never set to zero.

## 2. No-free-component rule

The following may not be made free in an authoritative promotion Gate:

- future target tokens, future hidden states, or a perfect accepted block;
- a perfect selector, perfect repair oracle, or target-output lookup;
- unimplemented compression, decompression, packing, transform, or kernel;
- checkpoint bytes, storage capacity, PCIe/HBM traffic, or materialization;
- cache construction, cache reads/writes, KV, workspace, fragmentation reserve,
  metadata, synchronization, reduction, verification, repair, rollback, or
  fallback;
- candidate states `N`, committed tokens `A`, rejected candidates, or state
  reconstruction;
- native 4B-Q4 baseline time, target bandwidth, target throughput, or target
  VRAM when they have not been measured.

A diagnostic oracle may still be used to understand a mathematical ceiling,
but it must be labeled `DIAGNOSTIC_ONLY`. It cannot produce `PROMOTE`, cannot
advance the active frontier, and cannot be described as deployable progress.

## 3. Reality-first decision order

```text
current physical storage and VRAM
-> causal information availability
-> exact/fail-closed executable semantics
-> fully charged operation and byte ledger
-> small public-checkpoint causal measurement
-> target-hardware measured baseline and bandwidth
-> kernel and complete successor-state integration
-> final 405B acceptance
```

A physical-capacity failure is not hidden behind a projected compression ratio.
A missing target baseline or bandwidth measurement blocks latency promotion.

## 4. Current registered target facts

The active target inventory is the sanitized EXP-073 host snapshot unless a
newer verified target record supersedes it:

```text
GPU                         Quadro M5000, compute capability 5.2
usable/free VRAM snapshot   8,058 MiB
PCIe exposed maximum        Gen2 x16
host RAM available          21.8865 GiB
root free storage           97.6183 GiB
raw registered BF16 405B    811,698,487,296 bytes
same-machine 4B Q4 p50/p95  NOT MEASURED
actual storage/H2D rates    NOT MEASURED
```

The exposed PCIe link ceiling may produce a `DERIVED` optimistic lower bound,
not a measured throughput claim.

## 5. Required result labels

Every authoritative result must state:

```text
MEASURED
DERIVED
PROJECTED
UNVERIFIED
REALITY_BLOCKERS
README_CURRENT
```

A mechanism with a promising mathematical fraction but unresolved storage,
exactness, cache, workspace, baseline, or bandwidth is retained only as a
restricted diagnostic or blocked candidate. It is not promoted.
