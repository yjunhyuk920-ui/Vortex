#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SOURCE_ID="${GITHUB_SHA:-local}"
cd "$ROOT"
python experiments/exp_101a/run_experiment.py \
  --config experiments/exp_101a/config.json \
  --output-dir "results/exp_101a/${SOURCE_ID}"
