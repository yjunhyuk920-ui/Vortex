from __future__ import annotations

import hashlib
import itertools
import json
import math
from dataclasses import asdict, dataclass
from typing import Any, Iterable, Mapping, Sequence

import numpy as np
from scipy.optimize import linprog


class PublicFMMFrontierError(RuntimeError):
    """Raised when the pinned catalog or optimistic rank oracle is inconsistent."""


@dataclass(frozen=True)
class CatalogBase:
    shape: tuple[int, int, int]
    rank: int
    fields: tuple[str, ...]
    source: str
    file: str
    verified: bool
    explicitable: bool | None

    @property
    def classical_rank(self) -> int:
        a, b, c = self.shape
        return a * b * c

    @property
    def rank_ratio(self) -> float:
        return self.rank / self.classical_rank

    @property
    def base_id(self) -> str:
        a, b, c = self.shape
        return f"{a}x{b}x{c}-r{self.rank}:{self.file or self.source}"

    def manifest(self) -> dict[str, Any]:
        row = asdict(self)
        row["shape"] = list(self.shape)
        row["classical_rank"] = self.classical_rank
        row["rank_ratio"] = self.rank_ratio
        row["base_id"] = self.base_id
        return row


@dataclass(frozen=True)
class OrientedBase:
    a: int
    b: int
    c: int
    rank: int
    base_id: str
    source: str

    @property
    def classical_rank(self) -> int:
        return self.a * self.b * self.c

    @property
    def log_saving(self) -> float:
        return math.log(self.classical_rank / self.rank)

    @property
    def oriented_id(self) -> str:
        return f"{self.a}x{self.b}x{self.c}-r{self.rank}:{self.base_id}"

    def manifest(self) -> dict[str, Any]:
        return {
            "a": self.a,
            "b": self.b,
            "c": self.c,
            "rank": self.rank,
            "classical_rank": self.classical_rank,
            "rank_ratio": self.rank / self.classical_rank,
            "base_id": self.base_id,
            "source": self.source,
            "oriented_id": self.oriented_id,
        }


@dataclass(frozen=True)
class TensorFamily:
    name: str
    rows: int
    columns: int
    count: int

    @property
    def parameters(self) -> int:
        return self.rows * self.columns * self.count


@dataclass(frozen=True)
class FractionalOracleResult:
    m: int | None
    k: int
    n: int
    ratio: float
    log_ratio: float
    active_bases: tuple[dict[str, Any], ...]
    dimension_usage: tuple[float | None, float, float]
    dimension_limits: tuple[float | None, float, float]
    solver_status: int
    solver_message: str

    def manifest(self) -> dict[str, Any]:
        return {
            "m": self.m,
            "k": self.k,
            "n": self.n,
            "ratio": self.ratio,
            "log_ratio": self.log_ratio,
            "active_bases": list(self.active_bases),
            "dimension_usage": list(self.dimension_usage),
            "dimension_limits": list(self.dimension_limits),
            "solver_status": self.solver_status,
            "solver_message": self.solver_message,
        }


def canonical_sha256(value: Any) -> str:
    payload = json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False
    ).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def git_blob_sha1(payload: bytes) -> str:
    header = f"blob {len(payload)}\0".encode("ascii")
    return hashlib.sha1(header + payload).hexdigest()


def _field_tokens(value: Any) -> tuple[str, ...]:
    if isinstance(value, str):
        normalized = value.replace("ℚ", "Q").replace("ℝ", "R").replace("ℤ", "Z")
        for separator in ("/", ",", "|", ";"):
            normalized = normalized.replace(separator, " ")
        return tuple(sorted({token.strip().upper() for token in normalized.split() if token.strip()}))
    if isinstance(value, Sequence) and not isinstance(value, (bytes, bytearray, str)):
        tokens: set[str] = set()
        for item in value:
            tokens.update(_field_tokens(item))
        return tuple(sorted(tokens))
    return ()


def is_characteristic_zero_real_compatible(fields: Sequence[str], *, complex_scheme: bool) -> bool:
    if complex_scheme:
        return False
    tokens = {str(value).upper() for value in fields}
    return bool(tokens.intersection({"Z", "Q", "R", "R/Q/Z"}))


def parse_catalog_manifest(
    payload: bytes,
    *,
    maximum_dimension: int,
    require_verified: bool = True,
) -> tuple[tuple[CatalogBase, ...], dict[str, Any]]:
    try:
        root = json.loads(payload)
    except json.JSONDecodeError as error:
        raise PublicFMMFrontierError(f"catalog JSON is invalid: {error}") from error
    if not isinstance(root, Mapping) or not isinstance(root.get("schemes"), list):
        raise PublicFMMFrontierError("catalog manifest must contain a schemes list")

    accepted: list[CatalogBase] = []
    rejection_counts: dict[str, int] = {}
    raw_count = 0
    for item in root["schemes"]:
        raw_count += 1
        reason: str | None = None
        if not isinstance(item, Mapping):
            reason = "non_object"
        else:
            shape_raw = item.get("format", item.get("n"))
            try:
                shape = tuple(int(value) for value in shape_raw)
            except (TypeError, ValueError):
                shape = ()
            if len(shape) != 3 or min(shape, default=0) <= 1:
                reason = "invalid_shape"
            elif max(shape) > int(maximum_dimension):
                reason = "dimension_out_of_scope"
            else:
                try:
                    rank = int(item.get("rank", item.get("m")))
                except (TypeError, ValueError):
                    rank = -1
                if rank <= 0 or rank >= math.prod(shape):
                    reason = "not_fast_rank"
                verified = bool(item.get("verified", False))
                if reason is None and require_verified and not verified:
                    reason = "not_verified"
                complex_scheme = bool(item.get("complex", False))
                fields = _field_tokens(item.get("fields", item.get("field", ())))
                if reason is None and not is_characteristic_zero_real_compatible(
                    fields, complex_scheme=complex_scheme
                ):
                    reason = "field_out_of_scope"
                explicitable_raw = item.get("explicitable")
                explicitable = (
                    bool(explicitable_raw) if explicitable_raw is not None else None
                )
                if reason is None and explicitable is False:
                    reason = "not_explicitable"
                if reason is None:
                    accepted.append(
                        CatalogBase(
                            shape=(int(shape[0]), int(shape[1]), int(shape[2])),
                            rank=rank,
                            fields=fields,
                            source=str(item.get("source", "unknown")),
                            file=str(item.get("file", "")),
                            verified=verified,
                            explicitable=explicitable,
                        )
                    )
        if reason is not None:
            rejection_counts[reason] = rejection_counts.get(reason, 0) + 1

    # Multiple catalog entries may encode the same oriented tensor. For a rank-only
    # capacity oracle, only the minimum rank can matter. Break ties deterministically.
    best_by_shape: dict[tuple[int, int, int], CatalogBase] = {}
    for base in accepted:
        incumbent = best_by_shape.get(base.shape)
        if incumbent is None or (base.rank, base.file, base.source) < (
            incumbent.rank,
            incumbent.file,
            incumbent.source,
        ):
            best_by_shape[base.shape] = base
    bases = tuple(sorted(best_by_shape.values(), key=lambda row: (row.shape, row.rank, row.file)))
    if not bases:
        raise PublicFMMFrontierError("no verified explicit characteristic-zero fast base survived")
    summary = {
        "generated": root.get("generated"),
        "raw_scheme_count": raw_count,
        "accepted_entry_count_before_shape_dedup": len(accepted),
        "best_shape_count": len(bases),
        "rejection_counts": rejection_counts,
        "minimum_omega_base": min(
            (omega_row(base) for base in bases), key=lambda row: row["omega"]
        ),
    }
    return bases, summary


def omega_row(base: CatalogBase) -> dict[str, Any]:
    volume = base.classical_rank
    omega = 3.0 * math.log(base.rank) / math.log(volume)
    return {
        "base_id": base.base_id,
        "shape": list(base.shape),
        "rank": base.rank,
        "omega": omega,
        "source": base.source,
        "file": base.file,
    }


def build_orientations(bases: Sequence[CatalogBase]) -> tuple[OrientedBase, ...]:
    best: dict[tuple[int, int, int], OrientedBase] = {}
    for base in bases:
        for a, b, c in sorted(set(itertools.permutations(base.shape))):
            row = OrientedBase(
                a=int(a),
                b=int(b),
                c=int(c),
                rank=base.rank,
                base_id=base.base_id,
                source=base.source,
            )
            key = (row.a, row.b, row.c)
            incumbent = best.get(key)
            if incumbent is None or (row.rank, row.base_id) < (
                incumbent.rank,
                incumbent.base_id,
            ):
                best[key] = row
    rows = tuple(sorted(best.values(), key=lambda row: (row.a, row.b, row.c, row.rank)))
    if not rows:
        raise PublicFMMFrontierError("orientation population is empty")
    return rows


def solve_fractional_rank_oracle(
    *,
    m: int | None,
    k: int,
    n: int,
    orientations: Sequence[OrientedBase],
) -> FractionalOracleResult:
    if k <= 1 or n <= 1 or (m is not None and m <= 1):
        raise PublicFMMFrontierError("target dimensions must exceed one")
    if not orientations:
        raise PublicFMMFrontierError("fractional oracle has no bases")

    objective = np.asarray(
        [math.log(row.rank / row.classical_rank) for row in orientations],
        dtype=np.float64,
    )
    constraint_rows: list[list[float]] = []
    limits: list[float] = []
    if m is not None:
        constraint_rows.append([math.log(row.a) for row in orientations])
        limits.append(math.log(m))
    constraint_rows.append([math.log(row.b) for row in orientations])
    limits.append(math.log(k))
    constraint_rows.append([math.log(row.c) for row in orientations])
    limits.append(math.log(n))

    result = linprog(
        objective,
        A_ub=np.asarray(constraint_rows, dtype=np.float64),
        b_ub=np.asarray(limits, dtype=np.float64),
        bounds=[(0.0, None)] * len(orientations),
        method="highs",
    )
    if not result.success or result.x is None or result.fun is None:
        raise PublicFMMFrontierError(
            f"fractional rank LP failed: status={result.status} message={result.message}"
        )
    x = np.asarray(result.x, dtype=np.float64)
    usage = np.asarray(constraint_rows, dtype=np.float64) @ x
    if np.any(usage > np.asarray(limits) + 1e-8):
        raise PublicFMMFrontierError("fractional rank LP violates a dimension budget")
    active: list[dict[str, Any]] = []
    for index in np.flatnonzero(x > 1e-9):
        row = orientations[int(index)]
        active.append(
            {
                "oriented_id": row.oriented_id,
                "a": row.a,
                "b": row.b,
                "c": row.c,
                "rank": row.rank,
                "fractional_levels": float(x[index]),
                "log_saving_contribution": float(x[index] * row.log_saving),
                "source": row.source,
            }
        )
    active.sort(key=lambda row: (-row["log_saving_contribution"], row["oriented_id"]))
    log_ratio = float(result.fun)
    ratio = float(math.exp(max(log_ratio, -745.0)))
    if not (0.0 < ratio <= 1.0 + 1e-12):
        raise PublicFMMFrontierError(f"invalid arithmetic ratio {ratio}")

    if m is None:
        dimension_usage: tuple[float | None, float, float] = (
            None,
            float(usage[0]),
            float(usage[1]),
        )
        dimension_limits: tuple[float | None, float, float] = (
            None,
            float(limits[0]),
            float(limits[1]),
        )
    else:
        dimension_usage = (float(usage[0]), float(usage[1]), float(usage[2]))
        dimension_limits = (float(limits[0]), float(limits[1]), float(limits[2]))
    return FractionalOracleResult(
        m=m,
        k=int(k),
        n=int(n),
        ratio=min(ratio, 1.0),
        log_ratio=log_ratio,
        active_bases=tuple(active),
        dimension_usage=dimension_usage,
        dimension_limits=dimension_limits,
        solver_status=int(result.status),
        solver_message=str(result.message),
    )


def aggregate_family_oracles(
    *,
    block_length: int | None,
    families: Sequence[TensorFamily],
    orientations: Sequence[OrientedBase],
) -> dict[str, Any]:
    family_rows: list[dict[str, Any]] = []
    weighted = 0.0
    total_parameters = 0
    for family in families:
        oracle = solve_fractional_rank_oracle(
            m=block_length,
            k=family.columns,
            n=family.rows,
            orientations=orientations,
        )
        weight = family.parameters
        weighted += weight * oracle.ratio
        total_parameters += weight
        family_rows.append(
            {
                "family": asdict(family),
                "parameter_weight": weight,
                "oracle": oracle.manifest(),
            }
        )
    if total_parameters <= 0:
        raise PublicFMMFrontierError("family population has no parameters")
    ratio = weighted / total_parameters
    return {
        "block_length": block_length,
        "weighted_arithmetic_ratio": ratio,
        "family_rows": family_rows,
        "total_parameter_weight": total_parameters,
    }


def synthetic_fractional_control() -> dict[str, Any]:
    base = CatalogBase(
        shape=(2, 2, 2),
        rank=7,
        fields=("Q", "R", "Z"),
        source="synthetic_strassen",
        file="synthetic",
        verified=True,
        explicitable=True,
    )
    result = solve_fractional_rank_oracle(
        m=8,
        k=8,
        n=8,
        orientations=build_orientations((base,)),
    )
    expected = (7.0 / 8.0) ** 3
    return {
        "expected_ratio": expected,
        "actual_ratio": result.ratio,
        "absolute_error": abs(result.ratio - expected),
        "passed": abs(result.ratio - expected) <= 1e-10,
    }
